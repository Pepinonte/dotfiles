#!bin/bash

# Manual aliases
alias sudo='sudo '
alias ..='cd ..'
alias ll='lsd -lh --group-dirs=first'
alias la='lsd -a --group-dirs=first'
alias l='lsd --group-dirs=first'
alias lla='lsd -lha --group-dirs=first'
alias ls='lsd --group-dirs=first'
alias cat='bat'
alias up='sudo pacman -Syu'
alias cdc='cd $HOME/Code'
alias cdd='cd $HOME/.dotfiles'
alias gs='git status'


