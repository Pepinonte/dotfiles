#/!bin/bash

yay -S - < $HOME/.dotfiles/archPaquets.txt
