#!bin/bash

alias code='code-insiders'
alias vi='nvim'
alias vs.='(code $PWD &>/dev/null &)'
alias nv.='(nvim $PWD)'
alias o.='(thunar $PWD &>/dev/null &)'

